// import React from "react";
// // import ReactDOM from "react-dom";
// import styled from "@emotion/styled";
// import BasicTreeExample from "./components/ChartTree";
// import StyledTreeExample from "./components/StyledChartTree";
// import data from '../data.json'
//
//
//
// const Title = styled.h2`
//   margin-top: 5rem;
//   :first-of-type {
//     margin-top: 0;
//   }
// `;
//
// export const Chart_ = () => {
//   return (
//     <div style={{ textAlign: "center" }}>
//       {/* <Title>Basic tree</Title>
//       <BasicTreeExample /> */}
//       <Title>Styled tree</Title>
//       <StyledTreeExample data={data}/>
//     </div>
//   );
// }


